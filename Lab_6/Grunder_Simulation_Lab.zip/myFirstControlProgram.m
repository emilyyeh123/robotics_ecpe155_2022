function myFirstControlProgram(robotObj)
    % Set constants for this program
    maxDuration = 5;  % Max time to allow the program to run (s)    
    
    % Initialize loop variables
    tStart = tic;        % Time limit marker
        
    % from ICR calculations:
    xdot = 0.04;
    theta = 3.3333;
	SetFwdVelAngVel(robotObj,(xdot),(theta/maxDuration));

    % Enter main loop
    while ((toc(tStart) < maxDuration) && GetRobotRunState(robotObj))
        
        DistanceSensor(robotObj)
        AngleSensor(robotObj)
        
        % Briefly pause to avoid continuous loop iteration
        pause(0.1)
    end
    
   %%
   % Reset Constants and re-run
   
   % Set constants for this program
    maxDuration = 10;  % Max time to allow the program to run (s)    
    
    % Initialize loop variables
    tStart = tic;        % Time limit marker
    
    % from FKM calculations:
    xdot = 0.04;
    
	SetFwdVelAngVel(robotObj,(xdot),0);

    % Enter main loop
    while ((toc(tStart) < maxDuration) && GetRobotRunState(robotObj))
        
        DistanceSensor(robotObj)
        AngleSensor(robotObj)
        
        % Briefly pause to avoid continuous loop iteration
        pause(0.1)
    end
     
%%
   % Reset Constants and re-run
   
   % Set constants for this program
    maxDuration = 1;  % Max time to allow the program to run (s)    
    
    % from ICR calculations:
    % New theta - old theta
    theta = 2.66667;
    
    % Initialize loop variables
    tStart = tic;        % Time limit marker
        
	SetFwdVelAngVel(robotObj,0,(theta/maxDuration));

    % Enter main loop
    while ((toc(tStart) < maxDuration) && GetRobotRunState(robotObj))
        
        DistanceSensor(robotObj)
        AngleSensor(robotObj)
        
        % Briefly pause to avoid continuous loop iteration
        pause(0.1)
    end
    
    
	SetFwdVelAngVel(robotObj,0,0);
    
end