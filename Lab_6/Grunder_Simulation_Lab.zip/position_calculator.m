function position = position_calculator(x, y, theta, xi, yi, thetai)
% Calculate the movement needed to achieve user designated position

positioni = [xi; yi; thetai];

position = [x; y; theta];

r = 0.02; % radius of each wheel
l = 0.03; % distance from robot center line to when center
x_diff = (positioni(1) - position(1));
y_diff = (positioni(2) - position(2));
d = sqrt(x_diff^2 + y_diff^2)

rot = d*2/r*1;

fprintf('The distance the robot should travel is: %1.2f', d);
disp(' ');
fprintf('The amount the robot should rotate is: %1.2f', rot);

end