%% Worksheet 5
% By: Uri Grunder
% February 8th, 2022
% ECPE-155 - Autonomous Robotics (the best class ever!)

% *NOTE* All distance measurements are given in meters. XD
% Start with a clean sheet
clear, clc

%%
% Problem A
%{ 
Given: The right wheel spins at 3 rad/s and the left wheel spins at 1 rad/s
what is the final position of the robot given a starting position of [0; 0; 0] 
and a travel time of 5 s? 
%}

% Apply the ICR Function
disp('From zero, the final position of the robot is: ');
disp('    x-coord   y-coord    rotat');
disp(ICR_fxn(3, 1, 5, 0, 0, 0)');

disp('For Problem A in Worksheet 4, my answers were: ');
disp('    x-coord   y-coord    rotat');
disp([0.02, 0   ,     3.33]);

disp('And the simulations answers were: ');
disp('    x-coord   y-coord    rotat');
disp([-0.015, 0.118, 3.392]);
   
disp('From Worksheet 4, my angle of rotation was correct but the other two coordnates were significantly off.');
disp('This is becuase I failed to consider the global reference change as I applied the FKM functions.');
disp('Intuitively, it makes sense that the robot would travel some distance in the global x and y directions.');
disp('In general, I appreciate the level of resolution in the MATLAB calculated answer.');
disp('An examination shows that the y coordinate was significantly off. The other two values match up well.');
disp('This is likely due to built in noise in the program.');

position_A = ICR_fxn(3,1, 5, 0, 0, 0);
x_A = position_A(1);
y_A = position_A(2);
theta_A = position_A(3);

%%
% Problem B
%{ 
Given: Starting at Position A, if the right wheel spins at 2 rad/s and the left wheel spins 
at 2 rad/s, what is the final position of the robot if the robot travels for 10s?
%}

% Apply the FKM Function
disp('From Position A, the final position of the robot is: ');
disp('    x-coord   y-coord    rotat');
disp(FKM_fxn(2, 10, x_A, y_A, theta_A)');

disp('For Problem B in Worksheet 4, my answers were: ');
disp('    x-coord   y-coord    rotat');
disp([-0.375, -0.063, 3.33]);

disp('And the simulations answers were: ');
disp('    x-coord   y-coord    rotat');
disp([-0.407, 0.039, 3.340]);
   
disp('Comparing the MATLAB calculationsto Worksheet 4, my answers are fairly close to the MATLAB calculated position matrix.');
disp('I contend that the math used to solve this problem was correct,however, the input I used for the initial position matrix was already off.');
disp('Poor quality input will only give poor quality output!');
disp('It is worth noting that in spite of inputting bad quality data, the difference between y coordinates is smaller between the MATLAB calculation and the worksheet than between the MATLAB calculation and the simulation.');
disp('The values from the MATLAB position calculations were fed into the simulation, it is interesting to note that the y-coordinate from the simulation is so different from the other two reporte values.');

position_B = FKM_fxn(2, 10, x_A, y_A, theta_A);
x_B = position_B(1);
y_B = position_B(2);
theta_B = position_B(3);

%%
% Problem C
%{ 
Given: Starting at Position B, if the right wheel spins at 4 rad/s and the left wheel spins
 at -4 rad/s, what is the final position of the robot if the robot travels for 1s? 
%}

% Apply the ICR Function
disp('From Position B, the final position of the robot is: ');
disp('    x-coord   y-coord    rotat');
disp(ICR_fxn(4, -4, 1, x_B, y_B, theta_B)');

disp('For Problem C in Worksheet 4, my answers were: ');
disp('    x-coord   y-coord    rotat');
disp([-0.375, -0.063, 5.967]);

disp('And the simulations answers were: ');
disp('    x-coord   y-coord    rotat');
disp([-0.406, 0.035, 6.04]);

disp('Comparing the MATLAB calculations against Worksheet 4, the difference in the x and y coordinates is another result of computing the wrong input values. I am more interested in the slight differences in rotaion angle on this problem.');
disp('In the last two problems I calculated the angle exactly, I suspect the slight difference may have been caused by small rounding errors in my calculations.');
disp('The same pattern of behavior is observed between the simulation and the other two calculations. The x-coordinate and the angle is very close but the y-coordinate is significantly off.');

