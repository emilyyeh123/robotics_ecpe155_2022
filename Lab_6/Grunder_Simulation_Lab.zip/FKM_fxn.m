function new_pose = FKM_fxn(phi, t, x, y, theta)
% Function that applies the Instantaneous Center of Rotation to solve for
% position. Should only be used when wheels have the same rate of rotation.

% phi_1 = rotational speed of the right wheel given in rad/s
% phi_2 = rotational speed of the left wheel given in rad/s
% t = the duration of the motion
% x, y, and theta are the previous pose coordinates

% Pre-defined variables
r = 0.02; % Radius of wheels in m
l = 0.03; % Distance from wheel to robot centerline in m

new_pose = [x + r * t * phi * cos(theta);
            y + r * t * phi * sin(theta);
                      theta             ];


end