function [new_pose, motion] = ICR_fxn(phi_1,phi_2, t, x, y, theta)
% Function that applies the Instantaneous Center of Rotation to solve for
% position

% phi_1 = rotational speed of the right wheel given in rad/s
% phi_2 = rotational speed of the left wheel given in rad/s
% t = the duration of the motion

% Pre-defined variables
r = 0.02; % Radius of wheels in m
l = 0.03; % Distance from wheel to robot centerline in m
phi_sum = phi_1 + phi_2;
phi_diff = phi_1 - phi_2;

% Determine the angular velocity
w = r * phi_diff / 2 / l;

% Determine the radius of the robot from the ICR
R = l * phi_sum / phi_diff;

% Define a matrix for the robots initial position
old_pose = [ R * sin(theta);
             R * cos(theta);
                 theta     ]

% Define the Rotation matrix
r_theta = [cos(w*t) -sin(w*t) 0;
           sin(w*t)  cos(w*t) 0;
              0         0     1]
          
delta_pose = [x - R * sin(theta);
              y + R * cos(theta);
                     w*t        ]
       
new_pose = r_theta * old_pose + delta_pose;

end