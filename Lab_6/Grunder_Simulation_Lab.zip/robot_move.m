function motion = robot_move(w, ang, t)

% Set constants for this program
    maxDuration = t;  % Max time to allow the program to run (s)    
    
    % Initialize loop variables
    tStart = tic;        % Time limit marker
        
	SetFwdVelAngVel(robotObj,w,ang);

    % Enter main loop
    while ((toc(tStart) < maxDuration) && GetRobotRunState(robotObj))
        
        DistanceSensor(robotObj)
        AngleSensor(robotObj)
        
        % Briefly pause to avoid continuous loop iteration
        pause(0.1)
    end
   
    
	SetFwdVelAngVel(robotObj,0,0);
end